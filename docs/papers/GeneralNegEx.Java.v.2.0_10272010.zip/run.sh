#!/bin/bash

# Runs the wrapper on the test kit.
java CallKit Annotations-1-120-random.txt yes
java Accuracy CallKit.result
